<?php $__env->startSection('content'); ?>

<br><center>
<h3>Solicitações em Aberto</h3>

<br><br>
<table class="table">
  <tr>
      <th>Nome</th>
      <th>Aluno</th>
      <th>Solicitada em</th>
      <th>Ações</th>
    </tr>
  <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><a href="<?php echo e(url('/download/info.pdf')); ?>" target="_blank"><?php echo e($s->name); ?></a></td>
    <td><?php echo e($s->solicitanteName($s)); ?></td>
    <td><?php echo e(date('F j, Y', strtotime($s->created_at))); ?></td>
    <?php
    $id = $s->id
    ?>
    <td><form action="<?php echo e(route('solicitacoes.update', $id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" value="Deferido" name="status" id="status">
        <input type="submit" class="btn btn-success btn-xs" value="Deferir"></a>
      </form>
      <form id="form2" action="<?php echo e(route('solicitacoes.update', $id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
          <input type="hidden" value="Indeferido" name="status" id="status">
          <input type="submit" class="btn btn-danger btn-xs" value="Indeferir"></a>
        </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.adminhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>