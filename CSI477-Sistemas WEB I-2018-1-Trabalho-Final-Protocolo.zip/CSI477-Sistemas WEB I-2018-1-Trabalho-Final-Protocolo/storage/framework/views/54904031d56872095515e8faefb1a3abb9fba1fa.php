<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('solicitacoes.store')); ?>">
  <?php echo csrf_field(); ?>

      <label for="name">Tipo:</label>
      <select name="name">
        <option value="">Selecione:</option>
        <!-- Estados //-->
          <option value="Trancamento de Matrícula">Trancamento de Matrícula</option>
          <option value="Solicitação de Histórico">Solicitação de Histórico</option>
          <option value="Aproveitamento de Matéria">Aproveitamento de Matéria</option>
          <option value="Quebra de Pré-Requisito">Quebra de Pré-Requisito</option>
      </select>

      <input type="submit" value="Cadastrar">
      <input type="reset" value="Limpar">

    </form>

     <a href="/download" class="btn btn-large pull-right"><i class="icon-download-alt"> </i> Download Brochure </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.userhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>