<?php $__env->startSection('content'); ?>

<h1>Solicitações Cadastradas</h1>

<table class="table">
  <tr>
      <th>ID</th>
      <th>Nome</th>
      <th>Status</th>
      <th>Cadastrado em</th>
      <th>Atualizado em</th>
    </tr>
  <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($solicitacao->id); ?></td>
    <td><?php echo e($solicitacao->name); ?></td>
    <td><?php echo e($solicitacao->status); ?></td>
    <td><?php echo e($solicitacao->created_at); ?></td>
    <td><?php echo e($solicitacao->updated_at); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<form method="post" action="<?php echo e(route('solicitacoes.update', [ 'solicitacao' => $solicitacao->id])); ?>" id="formlogin" name="formlogin" >
      <?php echo csrf_field(); ?>
       <?php echo method_field('PATCH'); ?>
    <fieldset id="fie">
    <legend>AVALIAÇÃO DE SOLICITAÇÃO</legend><br />
    <legend>Selecione o solicitação a ser deferida ou indeferida</legend><br />
    <div class="form-group" id="id">
      Solicitação:
            <!-- <input type="text" name="estado_id"> <br> //-->
            <select name="id">
              <option value="">Selecione:</option>
              <!-- Dados dos estados //-->
              <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
      <div class="alert alert-danger" style="display: none" id="alertaID">
                    Campo obrigatório.
      </div><br><br>
      <div class="">
        Avaliação:
        <select name="status" id="status">
          <option value="">Selecione:</option>
          <!-- Dados dos estados //-->
            <option value="Deferido">Deferido</option>
            <option value="Indeferido">Indeferido</option>
            <option value="Em avaliacao">Em avaliação</option>
        </select>
      </div>
    <br>
    <input class="btn btn-primary" type="submit" value="ATUALIZAR    "  />
    </fieldset>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.adminhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>