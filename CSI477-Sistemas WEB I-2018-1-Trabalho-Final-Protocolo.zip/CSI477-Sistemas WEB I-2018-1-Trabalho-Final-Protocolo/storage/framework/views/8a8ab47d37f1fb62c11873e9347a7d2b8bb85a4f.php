<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <title>Admin Home</title>
  </head>
  <body>
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Analysis</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo e(route('adminhome')); ?>">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="<?php echo e(route('adminlistar')); ?>">Listar Usuários</a></li>
          <li><a href="<?php echo e(route('avaliarsolicitacoes')); ?>">Avaliação de Procedimentos</a></li>
          <li><a href="">Atualizar</a></li>
          <li><a href="">Excluir</a></li>
        </ul>
      </li>
      <li><a href="">Logout</a></li>
    </ul>
  </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  </body>
</html>
