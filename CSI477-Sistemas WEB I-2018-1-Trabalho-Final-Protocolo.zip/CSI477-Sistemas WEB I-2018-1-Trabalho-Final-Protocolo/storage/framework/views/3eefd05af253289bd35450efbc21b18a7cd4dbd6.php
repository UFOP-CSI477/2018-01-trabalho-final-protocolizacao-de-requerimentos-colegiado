<?php $__env->startSection('content'); ?>
<br><center>
<h3>Suas solicitações</h3>

<div style="overflow-x:auto;">
<table class="table">
    <tr>
        <th>Nome</th>
        <th>Data</th>
        <th>Status</th>
      </tr>
  <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if(is_null($s->status)): ?>
    <tr class="blue">
  <?php endif; ?>
  <?php if($s->status == "Indeferido"): ?>
    <tr class="red">
  <?php endif; ?>
  <?php if($s->status == "Deferido"): ?>
    <tr class="green">
  <?php endif; ?>
    <td><?php echo e($s->name); ?></td>
    <td><?php echo e(date('F j, Y', strtotime($s->created_at))); ?></td>
    <td><?php if(is_null($s->status)): ?>
          Aguardando
        <?php endif; ?>
        <?php if(!is_null($s->status)): ?>
          <?php echo e($s->status); ?>

        <?php endif; ?>
         </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.userhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>