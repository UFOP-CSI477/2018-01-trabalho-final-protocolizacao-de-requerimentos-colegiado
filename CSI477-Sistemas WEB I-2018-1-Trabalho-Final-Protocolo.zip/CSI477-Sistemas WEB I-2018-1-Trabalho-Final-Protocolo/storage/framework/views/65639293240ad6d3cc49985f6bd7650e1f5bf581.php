<?php $__env->startSection('content'); ?>

<h1>Lista de Usuários</h1>

<table class="table">
  <tr>
      <th>ID</th>
      <th>Nome</th>
      <th>Tipo</th>
      <th>Cadastrado em</th>
      <th>Atualizado em</th>
    </tr>
  <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($usuario->id); ?></td>
    <td><?php echo e($usuario->name); ?></td>
    <td><?php if($usuario->type == 2): ?>
            Técnico Administrativo
        <?php endif; ?>
        <?php if($usuario->type == 1): ?>
            Aluno
        <?php endif; ?>
    </td>
    <td><?php echo e(date('F j, Y', strtotime($usuario->created_at))); ?></td>
    <td><?php echo e(date('F j, Y', strtotime($usuario->updated_at))); ?> as <?php echo e(date('H: i', strtotime($usuario->updated_at))); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.adminhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>