<?php $__env->startSection('content'); ?>
<center>
<h3>Trancamento de Matrícula</h3>
<br>
<form method="post" action="<?php echo e(route('solicitacoes.create')); ?>">
	<?php echo csrf_field(); ?>
	<a href="<?php echo e(url('/download/info.pdf')); ?>" target="_blank"><input type="button" class="btn btn-secondary" value="Download do Arquivo"></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.userhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>